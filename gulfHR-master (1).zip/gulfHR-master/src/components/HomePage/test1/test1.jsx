import React from 'react'

const test1 = () => {
  return (
    <div className='flex'>
        <div></div>
        <div className={"flex"}>
            <div></div>
            <div></div>
        </div>
    </div>
  )
}

export default test1